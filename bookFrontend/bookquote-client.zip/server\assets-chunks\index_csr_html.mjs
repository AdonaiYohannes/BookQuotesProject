export default `<!doctype html>
<html lang="sv" data-beasties-container="">
<head>
<meta charset="utf-8">
<title>BookQuotes</title>
<base href="/">
<meta name="viewport" content="width=device-width, initial-scale=1">


<!-- Bootstrap 5 -->
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">


<!-- Font Awesome -->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" integrity="sha512-SOMEHASH" crossorigin="anonymous" referrerpolicy="no-referrer">
<style>:root{--bg:#ffffff;--fg:#111827;--card:#f8f9fa}body{background:var(--bg);color:var(--fg)}</style><link rel="stylesheet" href="styles-LW3UAERC.css" media="print" onload="this.media='all'"><noscript><link rel="stylesheet" href="styles-LW3UAERC.css"></noscript></head>
<body ngcm="">
<app-root></app-root>


<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
<link rel="modulepreload" href="chunk-TYNFT3E5.js"><link rel="modulepreload" href="chunk-5QS6CMCQ.js"><link rel="modulepreload" href="chunk-S235YQ3A.js"><link rel="modulepreload" href="chunk-3DHCUJKL.js"><script src="main-B4IXTBC4.js" type="module"></script></body>
</html>`;