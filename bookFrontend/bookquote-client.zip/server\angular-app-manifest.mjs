
export default {
  bootstrap: () => import('./main.server.mjs').then(m => m.default),
  inlineCriticalCss: true,
  baseHref: '/',
  locale: undefined,
  routes: [
  {
    "renderMode": 0,
    "preload": [
      "chunk-JFOB2CXQ.js"
    ],
    "route": "/"
  },
  {
    "renderMode": 0,
    "preload": [
      "chunk-VAPFIQ2F.js",
      "chunk-I7BYOEZP.js"
    ],
    "route": "/login"
  },
  {
    "renderMode": 0,
    "preload": [
      "chunk-YB2QBX6F.js",
      "chunk-I7BYOEZP.js"
    ],
    "route": "/register"
  },
  {
    "renderMode": 0,
    "preload": [
      "chunk-3NTCWV5O.js",
      "chunk-BXZQ3W76.js"
    ],
    "route": "/books"
  },
  {
    "renderMode": 0,
    "preload": [
      "chunk-OXX4CEZN.js",
      "chunk-BXZQ3W76.js",
      "chunk-I7BYOEZP.js"
    ],
    "route": "/book/new"
  },
  {
    "renderMode": 0,
    "preload": [
      "chunk-OXX4CEZN.js",
      "chunk-BXZQ3W76.js",
      "chunk-I7BYOEZP.js"
    ],
    "route": "/book/*"
  },
  {
    "renderMode": 0,
    "preload": [
      "chunk-43V4A3ZV.js",
      "chunk-I7BYOEZP.js"
    ],
    "route": "/my-quotes"
  },
  {
    "renderMode": 0,
    "redirectTo": "/",
    "route": "/**"
  }
],
  entryPointToBrowserMapping: undefined,
  assets: {
    'index.csr.html': {size: 1439, hash: '94dfd940b2ae3490fd176479e27cb5ad3bc5e0a8a40194b4cd1b5866c5ec974a', text: () => import('./assets-chunks/index_csr_html.mjs').then(m => m.default)},
    'index.server.html': {size: 1742, hash: '68604c602a2f4237d13760b5eb0a4c33b7ebff799b9d42cfae74b1e7924e2646', text: () => import('./assets-chunks/index_server_html.mjs').then(m => m.default)},
    'styles-LW3UAERC.css': {size: 478, hash: 'ZxnHvdmgZ2A', text: () => import('./assets-chunks/styles-LW3UAERC_css.mjs').then(m => m.default)}
  },
};
