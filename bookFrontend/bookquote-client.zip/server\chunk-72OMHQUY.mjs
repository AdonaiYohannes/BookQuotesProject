import './polyfills.server.mjs';
var o={production:!1,apiBaseUrl:"http://localhost:5140/api"};export{o as a};
